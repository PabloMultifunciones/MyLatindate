<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require_once 'PHPMailer/class.phpmailer.php';

class SendMailer extends PHPMailer
{
    function __construct()
    {

    }
}
/* application/libraries/Mailer.php */