<!DOCTYPE html>
<html lang="en">

<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="utf-8">
	<meta name="description" content="Have the perfect date and find your latin love">
	<meta property="og:site_name" content="My Latin Date">
	<meta property="og:title" content="My Latin Date">
	<meta property="og:description" content="Have the perfect date and find your latin love">
	<meta name="language" content="en">
	<meta name="keywords" content="my, latin, date, have, perfect, date, find, latin, love">
	<meta property="og:type" content="website">
	<meta property="og:url" content="https://www.mylatindate.com">
	<meta property="og:image" content="https://www.mylatindate.com/img/src/favicon.png">
	<meta property="og:image:width" content="96">
	<meta property="og:image:height" content="96">
	<meta property="author" content="Duduar Coder">
	<meta name="copyright" content="My Latin Media" />
	<meta http-equiv="Expires" content="0">
	<meta http-equiv="Last-Modified" content="0">
	<meta http-equiv="Cache-Control" content="no-cache, mustrevalidate">
	<meta http-equiv="Pragma" content="no-cache">

	<title>Mylatindate</title>

	<link rel="shorcut icon" href="<?php echo base_url('img/src/favicon.png'); ?>" type="image/png">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,800&display=swap">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="<?php echo base_url('css/master.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('css/menu-styles.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('css/index-styles.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('css/lib/control/iconselect.css'); ?>">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url('js/js.cookie.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('js/lib/control/iconselect.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('js/lib/iscroll.js'); ?>"></script>

	<script>
		window.fbAsyncInit = function() {
			FB.init({
				appId      : '2351089331858923',
				cookie     : true,                     
				xfbml      : true,                     
				version    : 'v7.0'           
			});
		};

		(function(d, s, id) {                      
			var js, fjs = d.getElementsByTagName(s)[0];
			if (d.getElementById(id)) return;
			js = d.createElement(s); js.id = id;
			js.src = "https://connect.facebook.net/en_US/sdk.js";
			fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));

		function checkLoginState() {               
			FB.getLoginStatus(function(response) {   
				statusChangeCallback(response);
			});
		}

		function statusChangeCallback(response) {                  
			if (response.status === 'connected') {  
				connectToFacebook(response.authResponse.accessToken);  
			}
		}

		function connectToFacebook(accessToken) {

			FB.api('/me', function(response) {

				var facebook_account_id = response.id;

				$.ajax({
					url      : '<?= base_url('home/login_facebook/') ?>',
					data     : { facebook_account_id:facebook_account_id, accessToken:accessToken },
					type     : 'POST',
					success  : function(resp) {
						console.log(resp);
						if (resp.trim() == "connect_ok_for_"+facebook_account_id) {
							location.reload();
						}
					}
				})
			});
		}
	</script>
</head>
<body class="body--index">
	<header class="hero-image">
		
		<div class="d-flex justify-content-end align-items-center">
			<form class="form-register pd-tp-15" action="<?php echo base_url('/Home/user_register'); ?>" method="post">
				<div class="inputs-container">
					<nav>
						<div class="center-to-parent">
							<p class="text-white">���<?= lang("already") ?>?</p>
							<a href="<?php echo base_url('Home/Login'); ?>" class="no-decoration text-uppercase login my-icon-select"><?= lang("login") ?></a>

							<div style="padding: 0px 15px" id="my-icon-select"></div>
							<div style="padding: 0px 30px"></div>
						</div>
					</nav>
					<img src="<?php echo base_url('img/src/logo.png'); ?>" alt="Logo Mylatindate">
					<p class="text-white text-uppercase form-title pd-t-2"><?= lang("free_join") ?></p>
					<div class="px-2 px-lg-4">
						<hr>
						<?php if (!empty($exists_user)) { echo $exists_user; } ?>
						<input type="text" class="margin-for-rows input-text" name="txt-username" placeholder="<?= lang("first_name") ?>" required>
						<div class="margin-for-rows gender-container">
							<div class="center-to-parent">
								<p class="text-white"><?= lang("iam") ?></p>
							</div>
							<div class="center-to-parent">

								<input type="radio" name="txt-gender" value="1" checked><img src="<?php echo base_url('img/src/icon_man.png'); ?>" alt="man-png">
								<input type="radio" name="txt-gender" value="2"><img src="<?php echo base_url('img/src/icon_woman.png'); ?>" alt="woman.png">
							</div>
						</div>
						<input type="email" class="margin-for-rows input-text" name="txt-email" placeholder="<?= lang("your_email") ?>" required>
						<input type="password" class="margin-for-rows input-text" name="txt-password" placeholder="<?= lang("your_password") ?>" required>
						<input type="submit" class="margin-for-rows cursor-pointer text-uppercase submit" name="submit_register" value="<?= lang("get_started_now") ?>!" style="background: #007bff; margin-top: 20px;">
						<div class="margin-for-rows form-divider">
							<div class="hr-container">
								<hr>
							</div>
							<div>
								<p class="text-uppercase text-white hr-divisor"><?= lang("or") ?></p>
							</div>
							<div class="hr-container">
								<hr>
							</div>
						</div>
						<p class="margin-for-rows text-white footer"><?= lang("text_join_facebook") ?></p>
					</div>
				</div>
			</form>
		</div>
	
		<div class="footer">
			<div class="center-to-parent">
				<p class="text-white p-title" style="text-shadow: 5px 5px 10px #000000;">
					<?= lang("have_the_perfect_date") ?>
				</p>
			</div>
		</div>
	</header>
