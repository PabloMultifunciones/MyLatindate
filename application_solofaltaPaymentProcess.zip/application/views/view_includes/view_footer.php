<footer class="margin-for-sections mg-0">
</footer>
<script type="text/javascript" src="<?php echo base_url('js/master.js?v='.rand()); ?>"></script>

</body>

</html>