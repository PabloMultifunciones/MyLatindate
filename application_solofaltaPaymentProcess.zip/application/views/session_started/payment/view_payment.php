<?php
$plan_active = $this->model_home->validate_plan($id_user);

if (isset($_GET['collection_id']) && isset($_GET['merchant_order_id']) && isset($_GET['preference_id'])) {
  $payment_id = htmlspecialchars(htmlentities($_GET['collection_id'])); 
  redirect(base_url('Payment/validate-plan/mercadopago/'.$payment_id), 'location');
}
?>

<?php if ($plan_active == "active") {

  $subscription = $this->model_home->validate_plan($id_user, "data");
  ?>

<div class="container-fluid">
  <div class="row">
    <div class="col-md-12 p-lr-200">

      <p class="bg-lg-blue text-center text-white m-0 fsize-22 title-pay">Platinum</p><br>
      <table class="w-100">
        <tr>
          <td class="w-50"><strong class="text-capitalize"><?= lang('months') ?>:</strong></td>
          <td class="w-50"><?php echo $subscription[0]['months']." ".lang('months'); ?></td>
        </tr>
        <tr>
          <td class="w-50"><strong><?= lang('start_date') ?>:</strong></td>
          <td class="w-50"><?php echo date("F j, Y, g:i a", strtotime($subscription[0]['date_start'])); ?></td>
        </tr>
        <tr>
          <td class="w-50"><strong><?= lang('final_date') ?>:</strong></td>
          <td class="w-50"><?php echo date("F j, Y, g:i a", strtotime($subscription[0]['date_end'])); ?></td>
        </tr>
        <tr>
          <td class="w-50"><strong><?= lang('transaction_id') ?>:</strong></td>
          <td class="w-50"><?php echo $subscription[0]['transaction_id']; ?></td>
        </tr>
        <tr>
          <td class="w-50"><strong>Payment method:</strong></td>
          <td class="w-50"><?php echo $subscription[0]['payment_method']; ?></td>
        </tr>
      </table><br>
    </div>
    <div class="col-md-12 div-upgrade-profile">
      <div class="w-100">
        <div class="div-img-upgrade w-100">
          <img class="img-upgrade d-block" src="<?php echo base_url('img/src/perfil-bar-false.png'); ?>"
            alt="Upgrade Now | Mylatindate.com">
        </div>
        <p class="text-center"><?= lang('text_membership_platinum') ?></p>
        <button class="btn_view_my_profile bg-lg-blue"><?= lang('plan_active') ?></button>
      </div>
    </div>
  </div>
</div>
<?php } else { ?>
<div class="container-fluid">
  <div class="row">
    <form action="<?php echo base_url('Payment/finish-payment'); ?>" method="POST">
      <div class="col-md-12 p-lr-200">
        <p class="text-left text-black font-weight-bold mt-5 fsize-22">Chosse a subscription</p><br>
      </div>
     


      <div class="step-one">
      <div class="">
        <br>
        <div class="p-lr-200">


          <div class="item-price w-100 m-auto row">
            <div class="p-2 p-md-5 bg-D2D4FA col-4">
              <label class="container-price">
                <h2 class="text-black text-center font-weight-bold">12<br>
                  <h6 class="text-center"><?= lang('months') ?></h6>
                </h2>
                <input type="radio" name="radio-plan" value="Plan 12">
                <span class="checkmark-price"></span>
              </label>
            </div>
            <div class="pd-15 col-8">
              <span class="fsize-20">$ 14.17 USD <?= lang('per_months') ?></span><br>
              <small>Billed in a single payment $ 169.99 USD</small>
            </div>
          </div>





          <div class="item-price w-100 m-auto row">
            <div class="p-2 p-md-5 bg-D2D4FA col-4">
              <label class="container-price">
                <h2 class="text-black text-center font-weight-bold">3<br>
                  <h6 class="text-center"><?= lang('months') ?></h6>
                </h2>
                <input type="radio" name="radio-plan" value="Plan 3" checked="checked">
                <span class="checkmark-price"></span>
              </label>
            </div>
            <div class=" pd-15 col-8">
              <span class="fsize-20">$ 26.66 USD <?= lang('per_months') ?></span><br>
              <small><?= lang('billed_payment') ?>Billed in a single payment $ 79.98 USD</small>
              <p class="bg-lg-blue text-center text-white m-0 fsize-14 best-price">Best price</p>
            </div>
          </div>



          <div class="item-price w-100 m-auto row">
            <div class="p-2 p-md-5 bg-D2D4FA col-4">
              <label class="container-price">
                <h2 class="text-black text-center font-weight-bold">1<br>
                  <h6 class="text-center"><?= lang('months') ?></h6>
                </h2>
                <input type="radio" name="radio-plan" value="Plan 1">
                <span class="checkmark-price"></span>
              </label>
            </div>
            <div class=" pd-15 col-8">
              <span class="fsize-20">$ 39.99 USD</span><br>
            </div>
          </div>


          <div class="item-price w-100 m-auto row">
            <div class="p-2 p-md-5 bg-D2D4FA col-4">
              <label class="container-price">
                <h2 class="text-black text-center font-weight-bold">1<br>
                  <h6 class="text-center">Week</h6>
                </h2>
                <input type="radio" name="radio-plan" value="Plan 1">
                <span class="checkmark-price"></span>
              </label>
            </div>
            <div class=" pd-15 col-8">
              <span class="fsize-20">$ 20.00 USD</span><br>
              <small><?= lang('billed_payment') ?> $<?php echo $get_pay_data[2]['total']; ?></small>
            </div>
          </div>



        </div>



      </div>
      <div class="col-md-12 p-lr-200 payment-methods">
        <br>
        <p class="m-0 fsize-18 font-weight-bold"><?= lang('choose_payment_method') ?></p><br>
        <label class="container-pay w-100">
          Cards
          <input type="radio" name="radio-pay" value="Mercadopago" checked="checked">
          <span class="checkmark-pay"></span>
          <img src="<?php echo base_url('img/src/pay_mercadopago.png'); ?>" alt="Pay Mercadopago | Mylatindate"
            class="img-pay">
        </label>
        <!-- <label class="container-pay">
          PayPal
          <input type="radio" name="radio-pay" value="Paypal">
          <span class="checkmark-pay"></span>
          <img src="<?php echo base_url('img/src/pay_paypal.png'); ?>" alt="Pay Paypal | Mylatindate" class="img-pay">
        </label>
        <label class="container-pay w-100">
          PayU
          <input type="radio" name="radio-pay" value="PayU">
          <span class="checkmark-pay"></span>
          <img src="<?php echo base_url('img/src/pay_payu.png'); ?>" alt="Pay PayU | Mylatindate" class="img-pay">
        </label> -->

        <!-- Terms -->

      

        <div class="form-check mt-3">
          <input class="form-check-input" type="checkbox" checked value="" id="one">
          <label class="form-check-label pl-20" for="one">
            I agree terms of service
          </label>
          <span class="icon-question bg-primary" data-toggle="modal" data-target="#oneTerms">
            <i class="fa fa-question text-white"></i>
          </span>
        </div>
        <div class="form-check mt-3">
          <input class="form-check-input" type="checkbox" value="" id="two">
          <label class="form-check-label pl-20" for="two">
            I agree privacy & policy
          </label>
          <span class="icon-question bg-primary"  data-toggle="modal" data-target="#twoTerms">
            <i class="fa fa-question text-white"></i>
          </span>
        </div>
        <div class="form-check mt-3">
          <input class="form-check-input" type="checkbox" value="" id="three">
          <label class="form-check-label pl-20" for="three">
            I agree cancellation policy 
          </label>
          <span class="icon-question bg-primary"  data-toggle="modal" data-target="#threeTerms">
            <i class="fa fa-question text-white"></i>
          </span>
        </div>



        <input type="submit" disabled="true" name="btn-finish-pay" id="btn-finish-pay" class="btn-disabled mt-4"
          value="<?= lang('update_category_now') ?>">
      </div>
      </div>

      <div class="step-two">
       
      </div>

      <!-- Terms modal -->
      
      <div class="modal fade" id="oneTerms" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 99999999;">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title title-modal" id="exampleModalLabel">TERMS OF SERVICE</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body font-weight-bold">
            Welcome to the "mylatindate.com" website
            The Website is only offered and available to Users who are
            18 years of age or older. By using the Website, you
            represent and warrant that you are 18 years of age. If you
            do not meet all of these conditions, you must not access or
            use the Website.
            The Website is a social media website and application
            service which allows Users to create a profile, upload
            photos and videos onto their profile, set a monthly
            subscription price payable by other Users who wish to view
            their User Content and thereby generate revenue from
            Fans.
            These Terms govern your use of the Website, including any
            content, functionality, and services. By registering with and
            using myadultfan.com, you hereby accept and agree to
            be bound by and abide by these Terms. If you do not want
            to agree to these Terms of Service, you must not access or
            use the Website.
            All User Account registration and profile information is
            truthful and accurate and that any User Content you
            provide is your own and does not infringe the intellectual
            property rights or any other proprietorial rights of a third
            party
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>


      <div class="modal fade" id="twoTerms" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 99999999;">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title title-modal" id="exampleModalLabel">PRIVACY & POLICY</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body font-weight-bold">
            Welcome to the "mylatindate.com" website
            Privacy is not a new concept. Humans have always
            desired privacy in their social as well as private lives. But
            the idea of privacy as a human right is a relatively modern
            phenomenon. Around the world, laws and regulations
            have been developed for the protection of data related to
            government, education, health, children, consumers,
            financial institutions, etc. This data is critical to the person it
            belongs to. Data privacy and security binds individuals
            and industries together and runs complex systems in our
            society. From credit card numbers and social security
            numbers to email addresses and phone numbers, our
            sensitive, personally identifiable information is important.
            This sort of information in unreliable hands can potentially
            have far-reaching consequences. Companies or websites
            that handle customer information are required to publish
            their Privacy Policies on their business websites. If you own
            a website, web app, mobile app or desktop app that
            collects or processes user data, you most certainly will
            have to post a Privacy Policy on your website (or give
            in-app access to the full Privacy Policy agreement).
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>


      <div class="modal fade" id="threeTerms" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 99999999;">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title title-modal" id="exampleModalLabel">PRIVACY & POLICY</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body font-weight-bold">
            Welcome to the "mylatindate.com" website
            You may cancel your subscription at any time to prevent
            future billing. To cancel your subscription and prevent
            future billing simply select 'Billing' from the Settings menu of
            Mylatindate.com to change your billing preferences. This
            will prevent any further charges from occurring. You will not
            be entitled to a partial refund of any unused membership
            fees if you have used the services for any part of your
            billing period.
            For the candellation policy do it with our payment partner
            https://support.ccbill.com/?language=english&page=sup
            port_form
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>

     


    </form>
  </div>
</div>
<?php } ?>
<br>

<script>
 $('.payment-methods').on( 'click', function() {
    if($('#one').is(':checked') && $('#two').is(':checked') && $('#three').is(':checked')){
      $('#btn-finish-pay').attr('disabled', false)
      $('#btn-finish-pay').removeClass('btn-disabled').addClass('btn-finish-pay')
    } else {
      $('#btn-finish-pay').attr('disabled', true)
      $('#btn-finish-pay').addClass('btn-disabled').removeClass('btn-finish-pay')
    }
});

$('.icon-question').on('click', function() {
  $('.step-one').css('display', 'none')
})
$('.modal').on('click', function() {
  $('.step-one').css('display', 'block')
})

</script>