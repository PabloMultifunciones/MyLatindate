<div class="side-banner side-banner--left"></div>
<div class="side-banner side-banner--right"></div>
<div class="bg-white">
	<section class="second-section pd-t-20 row">
		<h2 class="col-md-12 margin-for-sections text-center text-capitalize text-primary py-3 mg-0 ">
			<?= lang("international_latin_dating") ?></h2>
		<div class="info-container mg-0 col-md-12 row">
			<div class="info col-md-12 col-lg-8 ">
				<p class="px-3">
					<?= lang("text_international_latin_dating") ?>
				</p>
			</div>
			<div class="img col-md-12 col-lg-4 d-flex justify-content-center align-items-center">
				<img class="w-340" src="<?php echo base_url('img/backgrounds/dinner.png'); ?>" alt="dinner.png">
			</div>
		</div>
	</section>

	<section class="second-section pt-5">
		<div class="latin-single">
			<div class="center-to-parent">
				<p class="text-white p-title text-center">
					<span class="text-bold text-white text-center"><?= lang("latin_singles") ?></span>
				</p>
			</div>
		</div>


		<div class="bg-latin-single mg-0 row">
			<div class="info info-single col-md-12 col-lg-8">
				<p class="py-4 px-3">
					<?= lang("text_latin_singles") ?>
				</p>
			</div>
			<div
				class="margin-for-sections icons-container mg-tb-20 col-md-12 col-lg-4 d-flex flex-column flex-md-row justify-content-center align-items-center">
				<div class="center-to-parent my-5 pd-lr-17">
					<img class="img-latin-single w-100" src="<?php echo base_url('img/src/build.png'); ?>"
						alt="icon.png">
				</div>
				<div class="center-to-parent my-5 pd-lr-17">
					<img class="img-latin-single w-100" src="<?php echo base_url('img/src/travel.png'); ?>"
						alt="icon.png">
				</div>
				<div class="center-to-parent mb-5 pd-lr-17">
					<img class="img-latin-single w-65" src="<?php echo base_url('img/src/bag.png'); ?>" alt="icon.png">
				</div>
			</div>
		</div>
	</section>

	<section class="margin-for-sections background-primary mg-0">
		<h2 class="text-center text-capitalize text-white fsize-50"><?= lang("how_it_works") ?></h2>
		<div class="margin-for-sections icons-container row">

			<div
				class="center-to-parent d-flex flex-column justify-content-center align-items-center col-md-12 col-lg-4">
				<img src="<?php echo base_url('img/src/ic_computer.png'); ?>" alt="icon.png" class="img-icon">
				<div class="description-container mt-3 px-5 px-lg-2">
					<p class="text-center text-bold text-white title">
						<?= lang("create_a_profile") ?>
					</p>
					<div class="description">
						<p class="text-center text-white">
							<?= lang("create_personalised_profile") ?>
						</p>
					</div>
				</div>
			</div>

			<div
				class="center-to-parent d-flex flex-column justify-content-center align-items-center col-md-12 col-lg-4">
				<img src="<?php echo base_url('img/src/ic_search.png'); ?>" alt="icon.png" class="img-icon">
				<div class="description-container mt-3 px-5 px-lg-2">
					<p class="text-center text-bold text-white title">
						<?= lang("browse_photos") ?>
					</p>
					<div class="description">
						<p class="text-center text-white">
							<?= lang("search_member") ?>
						</p>
					</div>
				</div>
			</div>

			<div
				class="center-to-parent d-flex flex-column justify-content-center align-items-center col-md-12 col-lg-4">
				<img src="<?php echo base_url('img/src/ic_chat.png'); ?>" alt="icon.png" class="img-icon">
				<div class="description-container mt-3 px-5 px-lg-2">
					<p class="text-center text-bold text-white title">
						<?= lang("start_communicating") ?>
					</p>
					<div class="description">
						<p class="text-center text-white">
							<?= lang("show_interest") ?>
						</p>
					</div>
				</div>
			</div>

		</div>

		<div class="margin-for-sections center-to-parent">
			<button type="button" class="text-uppercase btn-find-match cursor-pointer"
				name="button"><?= lang("find_match") ?></button>
		</div>
	</section>

	<section class="margin-for-sections background-simple mg-0 pd-tp-20 bg-start-success">
		<h2 class="text-center text-capitalize"><?= lang("start_success") ?></h2>
		<div class="margin-for-rows center-to-parent">
			<img src="<?php echo base_url('img/src/logo_black.png'); ?>" alt="logo.png">
		</div>
		<hr class="margin-for-rows">
		<div class="margin-for-sections icons-container row">
			<div class="center-to-parent d-flex flex-column justify-content-center align-items-center col-md-12 col-lg-4">
				<img src="<?php echo base_url('img/src/ic_protection.png'); ?>" alt="icon.png" class="img-icon">
				<div class="description-container mt-4 px-5 px-lg-2">
					<p class="text-center text-bold text-blue title margin">
						<?= lang("protection") ?>
					</p>
					<div class="description">
						<p class="text-center">
							<?= lang("text_protection") ?>
						</p>
					</div>
				</div>
			</div>
			<div class="center-to-parent d-flex flex-column justify-content-center align-items-center col-md-12 col-lg-4">
				<img src="<?php echo base_url('img/src/ic_verification.png'); ?>" alt="icon.png" class="img-icon">
				<div class="description-container mt-4 px-5 px-lg-2">
					<p class="text-center text-bold text-blue title margin">
						<?= lang("verification") ?>
					</p>
					<div class="description">
						<p class="text-center">
							<?= lang("text_verification") ?>
						</p>
					</div>
				</div>
			</div>
			<div class="center-to-parent d-flex flex-column justify-content-center align-items-center col-md-12 col-lg-4">
				<img src="<?php echo base_url('img/src/ic_atention.png'); ?>" alt="icon.png" class="img-icon">
				<div class="description-container mt-4 px-5 px-lg-2">
					<p class="text-center text-bold text-blue title margin">
						<?= lang("attention") ?>
					</p>
					<div class="description">
						<p class="text-center">
							<?= lang("text_attention") ?>
						</p>
					</div>
				</div>
			</div>
		</div>


	</section>
</div>